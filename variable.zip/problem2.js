
let name = "Amaan";
console.log(name);

let father_name = "Aas Mohammad";
console.log(father_name);

let Mothername = "Meena";
console.log(Mothername);



