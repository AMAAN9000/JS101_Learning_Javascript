
█▀█ █▀▀ █▀█ █▀█ █▀█ ▀█▀   █▀▀ ▄▀█ █▀█ █▀▄
█▀▄ ██▄ █▀▀ █▄█ █▀▄ ░█░   █▄▄ █▀█ █▀▄ █▄▀



let name = "Amaan";
let school_name = "Delhi Public School"; 
let section_ofstudent = "A";
let rollnumber = 14;
let marksinenglish = 50;
let marksinhindi = 78;
let marksinmaths = 90;

console.log("Name of student  :",name);
console.log("School Name :", school_name);
console.log(" sectionn  :",section_ofstudent);
console.log("Roll number :",rollnumber);
console.log("marks in english :" ,marksinenglish);
console.log("marks in hindi :",marksinhindi);
console.log("marksinmaths :" ,marksinmaths);
