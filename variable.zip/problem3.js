
let name = "Amaan";
let age = 20;
console.log(name);
console.log(typeof(name));

console.log(age);
console.log(typeof(age));

