

console.log("Masai school");

console.log("A Transformat in Education");
